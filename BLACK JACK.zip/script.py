import random

# Card values
cards = {
    "2": 2, "3": 3, "4": 4, "5": 5, "6": 6,
    "7": 7, "8": 8, "9": 9, "10": 10,
    "J": 10, "Q": 10, "K": 10, "A": 11
}

def deal_card():
    return random.choice(list(cards.keys()))

def calculate_hand(hand):
    value = sum(cards[card] for card in hand)
    aces = hand.count("A")

    # Adjust for Aces
    while value > 21 and aces:
        value -= 10
        aces -= 1

    return value

def blackjack():
    print("♠️ Welcome to Blackjack ♠️")

    player_hand = [deal_card(), deal_card()]
    dealer_hand = [deal_card(), deal_card()]

    while True:
        player_value = calculate_hand(player_hand)
        print(f"\nYour hand: {player_hand} (Value: {player_value})")
        print(f"Dealer shows: {dealer_hand[0]}")

        if player_value > 21:
            print("💥 Bust! You lose.")
            return

        move = input("Hit or Stand? (h/s): ").lower()
        if move == "h":
            player_hand.append(deal_card())
        elif move == "s":
            break

    # Dealer's turn
    while calculate_hand(dealer_hand) < 17:
        dealer_hand.append(deal_card())

    dealer_value = calculate_hand(dealer_hand)
    print(f"\nDealer hand: {dealer_hand} (Value: {dealer_value})")

    if dealer_value > 21 or player_value > dealer_value:
        print("🎉 You win!")
    elif player_value < dealer_value:
        print("😢 You lose.")
    else:
        print("🤝 Push (tie).")

if __name__ == "__main__":
    blackjack()